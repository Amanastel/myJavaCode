package com.masai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityWithSimpleRoleJwt2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityWithSimpleRoleJwt2Application.class, args);
	}

}
