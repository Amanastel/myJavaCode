package com.masai.exception;

public class CustomerException extends RuntimeException {

	
	public CustomerException() {
		// TODO Auto-generated constructor stub
	}
	
	public CustomerException(String message) {
		super(message);
	}
}
