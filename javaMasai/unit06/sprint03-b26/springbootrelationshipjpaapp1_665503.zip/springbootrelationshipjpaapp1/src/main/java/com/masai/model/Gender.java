package com.masai.model;

public enum Gender {

	MALE,FEMALE
}
